from django.apps import AppConfig


class CeleryHeartbeatConfig(AppConfig):
    name = 'celery_heartbeat'
